import socket
import json
import tkinter as tk
from tkinter import ttk

#create GUI window
root=tk.Tk()
root.title("Packet Analyzer Dashboard")
root.geometry("800x400")

#Table
tree=ttk.Treeview(root,columns=("Source","Destination","Protocol"),show="headings")
tree.heading("Source",text="Source IP")
tree.heading("Destination",text="Destination IP")
tree.heading("Protocol",text="Protocol")
tree.pack(fill=tk.BOTH,expand=True)

#connect to c++ server
client=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
client.connect(("127.0.0.1",9090))
buffer=""

def receive_packets():
    global buffer
    try:
        data=client.recv(4096).decode()
        if data:
            buffer+=data
            while "\n" in buffer:
                line,buffer=buffer.split("\n",1)
                packet=json.loads(line)
                tree.insert("",tk.END,values=(
                    packet["src_ip"],
                    packet["dst_ip"],
                    packet["protocol"]
                    )
                            )
    except:
        pass
    root.after(100,receive_packets)
tree.insert("",tk.END,values=("im source ip","im dst ip","im protocol"))
receive_packets()
root.mainloop()
